var currentDocument = document.currentScript.ownerDocument;
console.log("CropperJS");

class Cropper extends HTMLElement{
    constructor(){
        super();
        console.log("Cropper Constructor");
    }
    
    connectedCallback(){
        const shadowRoot = this.attachShadow({
            mode: 'open'
        });
        const template = currentDocument.querySelector("#cropper-comp").content;
        console.log("template:",template);
        const instance = template.cloneNode(true);

        // adding instance first and then adding event listener later by query shadowRoot
        shadowRoot.appendChild(instance);
        
    }

}
customElements.define('cropper-wc', Cropper);